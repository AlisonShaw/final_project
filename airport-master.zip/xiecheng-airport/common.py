#!/usr/bin/env python3
import hashlib
import os
import csv
import requests
import logging
import sys
from tenacity import retry, retry_if_exception_type, wait_fixed, stop_after_attempt,before_log

# logging.basicConfig(stream=sys.stderr, level=logging.INFO)

logger = logging.getLogger(__name__)

class BaseInfo:
    headers = {
        'Host': 'flights.ctrip.com',
        'scope': 'd',
        'accept': 'application/json',
        'cache-control': 'no-cache',
        'transactionid': '8d1fe88ae20845f5906ca60072ac2840',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36',
        'content-type': 'application/json;charset=UTF-8',
        'origin': 'https://flights.ctrip.com',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': 'https://flights.ctrip.com/international/search/oneway-bjs-can?depdate=2021-02-19&cabin=y_s_c_f&adult=1&child=0&infant=0&containstax=1',
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
    }
    heardName = ['flightNo', 'sequenceNo', 'marketAirlineCode', 'marketAirlineName', 'departureCountryName',
                 'departureProvinceId', 'departureCityId', 'departureCityCode', 'departureCityName',
                 'departureAirportCode',
                 'departureAirportName', 'departureAirportShortName', 'departureTerminal', 'arrivalCountryName',
                 'arrivalProvinceId', 'arrivalCityId', 'arrivalCityCode', 'arrivalCityName', 'arrivalAirportCode',
                 'arrivalAirportName', 'arrivalAirportShortName', 'arrivalTerminal', 'duration', 'transferDuration',
                 'stopList', 'aircraftCode', 'aircraftName', 'aircraftSize', 'departureDateTime', 'arrivalDateTime',
                 'leakedVisaTagSwitch', 'trafficType', 'mealType', 'arrivalPunctuality', 'highLightPlaneNo',
                 'minAdultPrice']
    outfileName = './data/flight.csv'
    cityNamePath = "./data/cityInfos.txt"
    cityThroughPath = "./data/cityThrough.csv"
    cityTagPath = "./data/tag.csv"
    transactionID = "d7099d6e80d94be2aac359dafc9f1e40"


def sign_param(transactionID, depDate, depCity, arrCity):
    '''
    生成加密sign参数
    :param transactionID:
    :type transactionID:
    :param depDate:
    :type depDate:
    :param depCity:
    :type depCity:
    :param arrCity:
    :type arrCity:
    :return:
    :rtype:
    '''
    value = transactionID + depCity + arrCity + depDate
    return hashlib.md5(value.encode()).hexdigest()


def writerHeardName(fileName, HEARDNAME):
    '''
    为结果文件写入表头
    :param fileName:
    :type fileName:
    :param HEARDNAME:
    :type HEARDNAME:
    :return:
    :rtype:
    '''
    if not os.path.isfile(fileName):
        with open(fileName, encoding="utf-8-sig", mode="w", newline="", errors="ignore") as f:
            writer = csv.DictWriter(f, fieldnames=HEARDNAME, extrasaction="ignore")
            writer.writeheader()


def judegeCityPair(dataObject):
    """
    判断城市之间是否存在航线
    :return:
    :rtype:
    """
    searchId = dataObject.get("data").get("context").get("searchId")
    if searchId == "null-null":
        return 1
    elif searchId == "":
        return 2
    else:
        return 0


def writeCsvRow(fileName, row):
    """
    向csv中写入list
    :param fileName:
    :type fileName:
    :param row:
    :type row:
    :return:
    :rtype:
    """
    with open(fileName, encoding="utf-8-sig", mode="a", newline="", errors="ignore") as f:
        wiriter = csv.writer(f)
        wiriter.writerow(row)


@retry(wait=wait_fixed(5), stop=stop_after_attempt(10),before=before_log(logger, logging.INFO))
def requestsData(session,headers, data,):
    response = session.post('https://flights.ctrip.com/international/search/api/search/batchSearch', headers=headers,
                             data=data,)
    return response




def getID(session,depDate):
    params = (
        ('depdate', f'{depDate}'),
    )
    response = session.get('https://flights.ctrip.com/international/search/api/flightlist/oneway-bjs-nng', params=params )
    transactionID = response.json().get("data").get("transactionID")
    return  transactionID


def getProxyABU():
    '''
    从配置文件中获取阿布云代理用户名参数，返回代理元
    in：None
    out：代理元
    '''
    proxyHost = "http-dyn.abuyun.com"
    proxyPort = "9020"
    # 代理隧道验证信息，根据购买的套餐，自行查看修改
    proxyUser = "HTU91860T6056VFD"
    proxyPass = "4C96D1D07C687D10"
    proxyMeta = "http://%(user)s:%(pass)s@%(host)s:%(port)s" % {
        "host": proxyHost ,
        "port": proxyPort ,
        "user": proxyUser ,
        "pass": proxyPass ,
    }

    proxies = {
        "http": proxyMeta ,
        "https": proxyMeta ,
    }
    return proxies


#更稳妥的代理测试
def ProxyTest(proxies):
    '''
    检测代理是否可用
    '''

    ip0=requests.get("http://ip-api.com/json/?lang=zh-CN").json().get('query')
    try:
        ip1=requests.get("http://ip-api.com/json/?lang=zh-CN",proxies=proxies).json().get('query')
    except:
        print("......代理故障，请检查配置......")
        return 0
    if ip0 != ip1:
        print("......代理启用成功，准备数据爬取......")
        return 1
    else:
        print("......代理故障，请检查配置......")
        return 0

