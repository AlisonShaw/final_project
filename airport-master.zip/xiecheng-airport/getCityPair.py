import requests
import json
import hashlib
from pprint import pprint
import os
import csv
import re
from itertools import combinations,permutations
from common import BaseInfo, judegeCityPair, writerHeardName, sign_param, writeCsvRow, requestsData

heardName = BaseInfo.heardName
outfileName = BaseInfo.outfileName
cityNamePath = BaseInfo.cityNamePath
cityThroughPAth = BaseInfo.cityThroughPath

writerHeardName(outfileName, heardName)

citypool = []
with open(cityNamePath, encoding="utf-8-sig", mode="r", newline="") as f:
    for each in f:
        citycode = re.findall('"(.*)":', each)[0]
        citypool.append(citycode)

transactionID = BaseInfo.transactionID
cityPair = [(depCity, arrCity) for (depCity, arrCity) in permutations(citypool, 2)]
transactionID = "0607db21a04e4fba9df5bdd068465c57"
depDate = "2021-02-09"

crawelPair = []
try:
    tagPath = "./data/tag.csv"
    with open(tagPath, mode="r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        for each in reader:
            crawelPair.append(each)
except:
    pass

headers = BaseInfo.headers
for depCity, arrCity in cityPair:
    if [depCity, arrCity] not in crawelPair:
        sign = sign_param(transactionID, depDate, depCity, arrCity)
        headers["sign"] = str(sign)
        data = f'{{\n\t"flightSegments": [{{\n\t\t"departureDate": "{depDate}",\n\n\n\t\t"departureCityCode": "{depCity}",\n\n\n\t\t"arrivalCityCode": "{arrCity}"\n\t}}],\n\t"transactionID": "{staticmethod}",\n\t"flightWay": "S"\n}}'
        response = requestsData(headers, data)
        print(response.status_code)
        jsonObj = response.json()
        if judegeCityPair(jsonObj):
            print(depCity, arrCity, "can through")
            writeCsvRow(cityThroughPAth, [depCity, arrCity])
        else:
            print(depCity, arrCity, "FAIL !!!!")
        writeCsvRow(tagPath, [depCity, arrCity])
    else:
        # print("REPEAT",[depCity,arrCity])
        pass


