import requests
import json
import hashlib
from pprint import pprint
import os
import csv
import time
import re
from itertools import combinations, permutations
from common import BaseInfo, judegeCityPair, writerHeardName, sign_param, writeCsvRow, requestsData,getID,getProxyABU,ProxyTest
from threading import BoundedSemaphore, Lock, Thread, Semaphore
from datetime import datetime, timedelta


def getinfo(cityPairItem, dateLength, seamphore):
    seamphore.acquire()
    transactionID = "8d1fe88ae20845f5906ca60072ac2840"
    if isinstance(dateLength, int):
        for delta in range(0, dateLength):
            now = datetime.now()
            date = now + timedelta(days=delta)
            depDate = date.strftime('%Y-%m-%d')
            depCity, arrCity = cityPairItem
            sign = sign_param(transactionID, depDate, depCity, arrCity)
            headers["sign"] = str(sign)
            data = f'{{\n\t"flightSegments": [{{\n\t\t"departureDate": "{depDate}",\n\n\n\t\t"departureCityCode": "{depCity}",\n\n\n\t\t"arrivalCityCode": "{arrCity}"\n\t}}],\n\t"transactionID": "{staticmethod}",\n\t"flightWay": "S"\n}}'
            session = requests.Session()
            response = requestsData(session,headers, data,)
            jsonObj = response.json()
            # print(f"{depCity} ----> {arrCity} at {depDate}....Now.... ")
            # print(jsonObj)
            judgeTag = judegeCityPair(jsonObj)
            if judgeTag == 0:
                flightItineraryList = jsonObj.get("data").get("flightItineraryList")
                for flightItinerary in flightItineraryList:
                    flightSegments = flightItinerary.get("flightSegments")
                    flightList = flightSegments[0].get("flightList")
                    ## 只收集直达飞机
                    if len(flightList) != 1:
                        continue
                    detialInfo = flightList[0]
                    priceList = flightItinerary.get("priceList")
                    adultPricePool = [singgleList.get("adultPrice") for singgleList in priceList]
                    detialInfo["minAdultPrice"] = min(adultPricePool)
                    print(
                        f"{detialInfo['departureCityName']} ----> {detialInfo['arrivalCityName']} at {depDate} is craweled ......")
                    with lock:
                        with open(outfilePath, encoding="utf-8-sig", mode="a", newline="", errors="ignore") as f:
                            wiriter = csv.DictWriter(f, fieldnames=heardName, extrasaction="ignore")
                            wiriter.writerow(detialInfo)
                writeCsvRow(dataPathSuccess, [depCity, arrCity])
                print(f"{depCity} ----> {arrCity} at {depDate} is craweled ......in {transactionID}")
            elif judgeTag == 2:
                transactionID = getID(session,depDate)
                headers["transactionid"]  = transactionID
                print(f"{depCity} ----> {arrCity} at {depDate} is BANNNED ......in {transactionID}")
            elif judgeTag == 1:
                writeCsvRow(dataPathSuccess, [depCity, arrCity])
                print(f"{depCity} ----> {arrCity} at {depDate} is emppty ......in {transactionID}")
            # time.sleep(1)
    seamphore.release()


def main():
    # if ProxyTest(proxies) == 0:
    #     return None
    # 由于接口不设置反爬,不利用Pair信息
    cityPair = []
    try:
        with open(cityTagPath, mode="r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            for each in reader:
                cityPair.append(tuple(each))
    except:
        pass

    success = []
    try:
        csv_reader = csv.reader(open(dataPathSuccess, errors="ignore", encoding="utf-8-sig"))
        for row in csv_reader:
            success.append(tuple(row))
    except Exception as e:
        print(e)
        pass

    pool = list(set(cityPair)-set(success))
    n = list(range(len((pool))))
    thread = []
    for i in n:
        t = Thread(target=getinfo, args=(pool[i], 7,semaphore))
        thread.append(t)
    for i in n:
        thread[i].start()
    for i in n:
        thread[i].join()


if __name__ == "__main__":
    heardName = BaseInfo.heardName
    outfilePath = BaseInfo.outfileName
    cityNamePath = BaseInfo.cityNamePath
    cityThroughPAth = BaseInfo.cityThroughPath
    cityTagPath = BaseInfo.cityTagPath
    dataPathSuccess = "./data/dataSuccesses.csv"
    writerHeardName(outfilePath, heardName)
    headers = BaseInfo.headers
    lock = Lock()
    semaphore = Semaphore(1)
    transactionID = "8d1fe88ae20845f5906ca60072ac2840"
    main()
