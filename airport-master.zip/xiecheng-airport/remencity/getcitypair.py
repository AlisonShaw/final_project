import  csv
from itertools import combinations
from contextlib import suppress
from datetime import datetime,timedelta
import re

def writeCsvRow(fileName, row):
    """
    向csv中写入list
    :param fileName:
    :type fileName:
    :param row:
    :type row:
    :return:
    :rtype:
    """
    with open(fileName, encoding="utf-8-sig", mode="a", newline="", errors="ignore") as f:
        wiriter = csv.writer(f)
        wiriter.writerow(row)


cityNamePath = "../data/cityInfos.txt"

city_id = {}
id_city ={}
with open(cityNamePath, encoding="utf-8-sig", mode="r", newline="") as f:
    for each in f:
        cityCode = re.findall('"(.*)":', each)[0]
        try:
            cityName = re.findall(':"(.*)"\r', each)[0]
        except Exception as e:
            cityName = re.findall(':"(.*)"',each)[0]
            print(e)
        print(cityCode,cityName)
        city_id[cityName] = cityCode

cityTarget=[]
with open("./cityname.txt",encoding = "utf-8-sig",mode = "r") as f:
    for each in f.readlines():
        each = each.replace("\n","")
        cityTarget.append(each)

crawerPool = []
for a,b in combinations(cityTarget,2):
    try:
            a= city_id[a]
            b= city_id[b]
            crawerPool.append([a,b])
            crawerPool.append([b,a])
    except Exception as e:
        print(e)
        pass

for each in crawerPool:
    writeCsvRow("./tag.csv",each)