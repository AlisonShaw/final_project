import requests
import json
import hashlib
from pprint import pprint
import os
import csv
from common import BaseInfo, judegeCityPair, writerHeardName, sign_param, writeCsvRow, requestsData,getID,getProxyABU,ProxyTest

HEARDNAME = ['flightNo', 'sequenceNo', 'marketAirlineCode', 'marketAirlineName', 'departureCountryName',
             'departureProvinceId', 'departureCityId', 'departureCityCode', 'departureCityName', 'departureAirportCode',
             'departureAirportName', 'departureAirportShortName', 'departureTerminal', 'arrivalCountryName',
             'arrivalProvinceId', 'arrivalCityId', 'arrivalCityCode', 'arrivalCityName', 'arrivalAirportCode',
             'arrivalAirportName', 'arrivalAirportShortName', 'arrivalTerminal', 'duration', 'transferDuration',
             'stopList', 'aircraftCode', 'aircraftName', 'aircraftSize', 'departureDateTime', 'arrivalDateTime',
             'leakedVisaTagSwitch', 'trafficType', 'mealType', 'arrivalPunctuality', 'highLightPlaneNo',
             'minAdultPrice']

fileName = r'./data/flight.csv'


if not os.path.isfile(fileName):
    with open(fileName, encoding="utf-8-sig", mode="w", newline="", errors="ignore") as f:
        wiriter = csv.DictWriter(f, fieldnames=HEARDNAME, extrasaction="ignore")
        wiriter.writeheader()


def sign_param(transactionID, depDate, depCity, arrCity):
    value = transactionID + depCity + arrCity + depDate
    return hashlib.md5(value.encode()).hexdigest()


transactionID = "8d1fe88ae20845f5906ca60072ac2840"
depDate = "2021-02-19"
depCity = "AKU"
arrCity = "BJS"

sign = sign_param(transactionID, depDate, depCity, arrCity)

headers = {
    'Host': 'flights.ctrip.com',
    'scope': 'd',
    'accept': 'application/json',
    'cache-control': 'no-cache',
    'transactionid': f'{transactionID}',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36',
    'sign': f'{sign}',
    'content-type': 'application/json;charset=UTF-8',
    'origin': 'https://flights.ctrip.com',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://flights.ctrip.com/international/search/oneway-bjs-can?depdate=2021-02-19&cabin=y_s_c_f&adult=1&child=0&infant=0&containstax=1',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

data = f'{{\n\t"flightSegments": [{{\n\t\t"departureDate": "{depDate}",\n\n\n\t\t"departureCityCode": "{depCity}",\n\n\n\t\t"arrivalCityCode": "{arrCity}"\n\t}}],\n\t"transactionID": "{staticmethod}",\n\t"flightWay": "S"\n}}'
response = requests.post('https://flights.ctrip.com/international/search/api/search/batchSearch', headers=headers,
                         data=data,)
jsonObj = response.json()
print(jsonObj)
flightItineraryList = jsonObj.get("data").get("flightItineraryList")
for flightItinerary in flightItineraryList:
    flightSegments = flightItinerary.get("flightSegments")
    flightList = flightSegments[0].get("flightList")
    ## 只收集直达飞机
    if len(flightList) != 1:
        continue
    detialInfo = flightList[0]
    priceList = flightItinerary.get("priceList")
    adultPricePool = [singgleList.get("adultPrice") for singgleList in priceList]
    detialInfo["minAdultPrice"] = min(adultPricePool)
    pprint(detialInfo)
    # with open(fileName, encoding="utf-8-sig", mode="a", newline="", errors="ignore") as f:
    #     wiriter = csv.DictWriter(f, fieldnames=HEARDNAME, extrasaction="ignore")
    #     wiriter.writerow(detialInfo)