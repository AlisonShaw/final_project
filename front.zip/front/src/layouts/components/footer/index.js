import React from 'react';
import styles from './style.less';

export default function() {
  return(
    <div className={styles.box}>
      {/* <p>
      作者 : XXX  | 学号 : 20163333 | <a href='https://www.baidu.com' target='_blank'>XXX</a> | <a href='https://www.baidu.com' target='_blank'>XXX</a>
      </p>
      <p>©XXX All Rights Reserved.</p> */}
    </div>
  )
};

