import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import _dvaDynamic from 'dva/dynamic';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__index" */ '../../layouts/index.js'),
        })
      : require('../../layouts/index.js').default,
    routes: [
      {
        path: '/arcgis',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__arcgis__model.js' */ 'E:/web_work/corona_virus/src/pages/arcgis/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__arcgis__index" */ '../arcgis/index.js'),
            })
          : require('../arcgis/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_fuwuchaxun',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_fuwuchaxun__model.js' */ 'E:/web_work/corona_virus/src/pages/a_fuwuchaxun/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_fuwuchaxun__index" */ '../a_fuwuchaxun/index.js'),
            })
          : require('../a_fuwuchaxun/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_fuwuchaxun/info',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_fuwuchaxun__info__model.js' */ 'E:/web_work/corona_virus/src/pages/a_fuwuchaxun/info/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__a_fuwuchaxun__model.js' */ 'E:/web_work/corona_virus/src/pages/a_fuwuchaxun/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_fuwuchaxun__info__index" */ '../a_fuwuchaxun/info/index.js'),
            })
          : require('../a_fuwuchaxun/info/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_guanxichaxun',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_guanxichaxun__model.js' */ 'E:/web_work/corona_virus/src/pages/a_guanxichaxun/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_guanxichaxun__index" */ '../a_guanxichaxun/index.js'),
            })
          : require('../a_guanxichaxun/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_shitishibie',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_shitishibie__model.js' */ 'E:/web_work/corona_virus/src/pages/a_shitishibie/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_shitishibie__index" */ '../a_shitishibie/index.js'),
            })
          : require('../a_shitishibie/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_shitishibie/info',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_shitishibie__info__model.js' */ 'E:/web_work/corona_virus/src/pages/a_shitishibie/info/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__a_shitishibie__model.js' */ 'E:/web_work/corona_virus/src/pages/a_shitishibie/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_shitishibie__info__index" */ '../a_shitishibie/info/index.js'),
            })
          : require('../a_shitishibie/info/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_shitishibie1',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_shitishibie1__model.js' */ 'E:/web_work/corona_virus/src/pages/a_shitishibie1/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_shitishibie1__index" */ '../a_shitishibie1/index.js'),
            })
          : require('../a_shitishibie1/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/a_tuijian',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__a_tuijian__model.js' */ 'E:/web_work/corona_virus/src/pages/a_tuijian/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__a_tuijian__index" */ '../a_tuijian/index.js'),
            })
          : require('../a_tuijian/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/base',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__base__model.js' */ 'E:/web_work/corona_virus/src/pages/base/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__base__index" */ '../base/index.js'),
            })
          : require('../base/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_guanxichaxun',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__b_guanxichaxun__model.js' */ 'E:/web_work/corona_virus/src/pages/b_guanxichaxun/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__b_guanxichaxun__index" */ '../b_guanxichaxun/index.js'),
            })
          : require('../b_guanxichaxun/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_import',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__b_import__model.js' */ 'E:/web_work/corona_virus/src/pages/b_import/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__b_import__index" */ '../b_import/index.js'),
            })
          : require('../b_import/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_jiance',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__b_jiance__model.js' */ 'E:/web_work/corona_virus/src/pages/b_jiance/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__b_jiance__index" */ '../b_jiance/index.js'),
            })
          : require('../b_jiance/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_kc',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__b_kc__model.js' */ 'E:/web_work/corona_virus/src/pages/b_kc/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__b_kc__index" */ '../b_kc/index.js'),
            })
          : require('../b_kc/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_ms',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__b_ms__index" */ '../b_ms/index.js'),
            })
          : require('../b_ms/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__b_search__model.js' */ 'E:/web_work/corona_virus/src/pages/b_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__b_search__index" */ '../b_search/index.js'),
            })
          : require('../b_search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/b_see',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__b_see__model.js' */ 'E:/web_work/corona_virus/src/pages/b_see/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__b_see__index" */ '../b_see/index.js'),
            })
          : require('../b_see/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/cesium_navigation',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__cesium_navigation__model.js' */ 'E:/web_work/corona_virus/src/pages/cesium_navigation/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__cesium_navigation__index" */ '../cesium_navigation/index.js'),
            })
          : require('../cesium_navigation/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/cesium_travel/flight',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__cesium_travel__model.js' */ 'E:/web_work/corona_virus/src/pages/cesium_travel/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__cesium_travel__flight__index" */ '../cesium_travel/flight/index.js'),
            })
          : require('../cesium_travel/flight/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/cesium_travel',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__cesium_travel__model.js' */ 'E:/web_work/corona_virus/src/pages/cesium_travel/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__cesium_travel__index" */ '../cesium_travel/index.js'),
            })
          : require('../cesium_travel/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/cesium_travel/train',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__cesium_travel__model.js' */ 'E:/web_work/corona_virus/src/pages/cesium_travel/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__cesium_travel__train__index" */ '../cesium_travel/train/index.js'),
            })
          : require('../cesium_travel/train/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/c_home',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__c_home__model.js' */ 'E:/web_work/corona_virus/src/pages/c_home/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__c_home__index" */ '../c_home/index.js'),
            })
          : require('../c_home/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/d_search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__d_search__model.js' */ 'E:/web_work/corona_virus/src/pages/d_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__d_search__index" */ '../d_search/index.js'),
            })
          : require('../d_search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/d_see',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__d_see__model.js' */ 'E:/web_work/corona_virus/src/pages/d_see/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__d_see__index" */ '../d_see/index.js'),
            })
          : require('../d_see/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/e_kc',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__e_kc__model.js' */ 'E:/web_work/corona_virus/src/pages/e_kc/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__e_kc__index" */ '../e_kc/index.js'),
            })
          : require('../e_kc/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/e_search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__e_search__model.js' */ 'E:/web_work/corona_virus/src/pages/e_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__e_search__index" */ '../e_search/index.js'),
            })
          : require('../e_search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/comments',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__comments__index" */ '../fish/comments/index.js'),
            })
          : require('../fish/comments/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/config/account',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__config__account" */ '../fish/config/account.js'),
            })
          : require('../fish/config/account.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/config',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__config__index" */ '../fish/config/index.js'),
            })
          : require('../fish/config/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/config/users',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__config__users" */ '../fish/config/users.js'),
            })
          : require('../fish/config/users.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__index" */ '../fish/index.js'),
            })
          : require('../fish/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/buhuo',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__buhuo" */ '../fish/info/buhuo.js'),
            })
          : require('../fish/info/buhuo.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/fangyang',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__fangyang" */ '../fish/info/fangyang.js'),
            })
          : require('../fish/info/fangyang.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/miaozhong',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__miaozhong" */ '../fish/info/miaozhong.js'),
            })
          : require('../fish/info/miaozhong.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/shebei',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__shebei" */ '../fish/info/shebei.js'),
            })
          : require('../fish/info/shebei.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/shiyong',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__shiyong" */ '../fish/info/shiyong.js'),
            })
          : require('../fish/info/shiyong.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/shuizhi',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__shuizhi" */ '../fish/info/shuizhi.js'),
            })
          : require('../fish/info/shuizhi.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/siliao',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__siliao" */ '../fish/info/siliao.js'),
            })
          : require('../fish/info/siliao.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/touliao',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__touliao" */ '../fish/info/touliao.js'),
            })
          : require('../fish/info/touliao.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/touyao',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__touyao" */ '../fish/info/touyao.js'),
            })
          : require('../fish/info/touyao.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/yaopin',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__yaopin" */ '../fish/info/yaopin.js'),
            })
          : require('../fish/info/yaopin.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/info/yutang',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__info__yutang" */ '../fish/info/yutang.js'),
            })
          : require('../fish/info/yutang.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/statistic/cost',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__statistic__cost" */ '../fish/statistic/cost.js'),
            })
          : require('../fish/statistic/cost.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/statistic/worktime',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__statistic__worktime" */ '../fish/statistic/worktime.js'),
            })
          : require('../fish/statistic/worktime.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/user',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__user__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__user__index" */ '../fish/user/index.js'),
            })
          : require('../fish/user/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/user/login',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__user__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__user__login__index" */ '../fish/user/login/index.js'),
            })
          : require('../fish/user/login/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/user/register',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__user__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__user__register__index" */ '../fish/user/register/index.js'),
            })
          : require('../fish/user/register/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/work/history',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__work__history" */ '../fish/work/history.js'),
            })
          : require('../fish/work/history.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fish/work/productPlan',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fish__model.js' */ 'E:/web_work/corona_virus/src/pages/fish/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fish__work__productPlan" */ '../fish/work/productPlan.js'),
            })
          : require('../fish/work/productPlan.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fupin',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fupin__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fupin__index" */ '../fupin/index.js'),
            })
          : require('../fupin/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fupin/login',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fupin__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fupin__login__index" */ '../fupin/login/index.js'),
            })
          : require('../fupin/login/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fupin/profile',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fupin__profile__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/profile/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__fupin__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fupin__profile__index" */ '../fupin/profile/index.js'),
            })
          : require('../fupin/profile/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fupin/profile/location',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fupin__profile__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/profile/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__fupin__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fupin__profile__location__index" */ '../fupin/profile/location/index.js'),
            })
          : require('../fupin/profile/location/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/fupin/register',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__fupin__model.js' */ 'E:/web_work/corona_virus/src/pages/fupin/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__fupin__register__index" */ '../fupin/register/index.js'),
            })
          : require('../fupin/register/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/gaodesearch',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__gaodesearch__model.js' */ 'E:/web_work/corona_virus/src/pages/gaodesearch/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__gaodesearch__index" */ '../gaodesearch/index.js'),
            })
          : require('../gaodesearch/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/home',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__home__model.js' */ 'E:/web_work/corona_virus/src/pages/home/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__home__index" */ '../home/index.js'),
            })
          : require('../home/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/huibao/colorPicker',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__huibao__model.js' */ 'E:/web_work/corona_virus/src/pages/huibao/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__huibao__colorPicker__index" */ '../huibao/colorPicker/index.js'),
            })
          : require('../huibao/colorPicker/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/huibao',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__huibao__model.js' */ 'E:/web_work/corona_virus/src/pages/huibao/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__huibao__index" */ '../huibao/index.js'),
            })
          : require('../huibao/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/huibao/layer',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__huibao__model.js' */ 'E:/web_work/corona_virus/src/pages/huibao/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__huibao__layer" */ '../huibao/layer.js'),
            })
          : require('../huibao/layer.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/huibao/mainCesium',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__huibao__model.js' */ 'E:/web_work/corona_virus/src/pages/huibao/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__huibao__mainCesium__index" */ '../huibao/mainCesium/index.js'),
            })
          : require('../huibao/mainCesium/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/huibao/sliderInput',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__huibao__model.js' */ 'E:/web_work/corona_virus/src/pages/huibao/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__huibao__sliderInput__index" */ '../huibao/sliderInput/index.js'),
            })
          : require('../huibao/sliderInput/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__index" */ '../index.js'),
            })
          : require('../index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/leaflet_windy',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__leaflet_windy__index" */ '../leaflet_windy/index.js'),
            })
          : require('../leaflet_windy/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/manage',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__manage__index" */ '../manage/index.js'),
            })
          : require('../manage/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/manage/student',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__manage__student__model.js' */ 'E:/web_work/corona_virus/src/pages/manage/student/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__manage__student__index" */ '../manage/student/index.js'),
            })
          : require('../manage/student/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/manage/user',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__manage__user__model.js' */ 'E:/web_work/corona_virus/src/pages/manage/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__manage__user__index" */ '../manage/user/index.js'),
            })
          : require('../manage/user/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/mapbox',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__mapbox__index" */ '../mapbox/index.js'),
            })
          : require('../mapbox/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/modelmanage',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__modelmanage__model.js' */ 'E:/web_work/corona_virus/src/pages/modelmanage/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__modelmanage__index" */ '../modelmanage/index.js'),
            })
          : require('../modelmanage/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/modelmanage/pie/fun',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__modelmanage__model.js' */ 'E:/web_work/corona_virus/src/pages/modelmanage/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__modelmanage__pie__fun" */ '../modelmanage/pie/fun.js'),
            })
          : require('../modelmanage/pie/fun.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/modelmanage/pie',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__modelmanage__model.js' */ 'E:/web_work/corona_virus/src/pages/modelmanage/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__modelmanage__pie__index" */ '../modelmanage/pie/index.js'),
            })
          : require('../modelmanage/pie/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/modelmanage/source',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__modelmanage__model.js' */ 'E:/web_work/corona_virus/src/pages/modelmanage/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__modelmanage__source__index" */ '../modelmanage/source/index.js'),
            })
          : require('../modelmanage/source/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/monitor/visualization',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__monitor__visualization__model.js' */ 'E:/web_work/corona_virus/src/pages/monitor/visualization/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__monitor__visualization__index" */ '../monitor/visualization/index.js'),
            })
          : require('../monitor/visualization/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/monitor/visualization/wrap',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__monitor__visualization__model.js' */ 'E:/web_work/corona_virus/src/pages/monitor/visualization/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__monitor__visualization__wrap__index" */ '../monitor/visualization/wrap/index.js'),
            })
          : require('../monitor/visualization/wrap/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/movie/comments',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__movie__model.js' */ 'E:/web_work/corona_virus/src/pages/movie/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__movie__comments__index" */ '../movie/comments/index.js'),
            })
          : require('../movie/comments/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/movie',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__movie__model.js' */ 'E:/web_work/corona_virus/src/pages/movie/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__movie__index" */ '../movie/index.js'),
            })
          : require('../movie/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/navigation',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__navigation__model.js' */ 'E:/web_work/corona_virus/src/pages/navigation/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__navigation__index" */ '../navigation/index.js'),
            })
          : require('../navigation/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/navigation/source',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__navigation__model.js' */ 'E:/web_work/corona_virus/src/pages/navigation/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__navigation__source__index" */ '../navigation/source/index.js'),
            })
          : require('../navigation/source/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/neo_django_country',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__neo_django_country__model.js' */ 'E:/web_work/corona_virus/src/pages/neo_django_country/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__neo_django_country__index" */ '../neo_django_country/index.js'),
            })
          : require('../neo_django_country/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/neo_django_country/info',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__neo_django_country__info__model.js' */ 'E:/web_work/corona_virus/src/pages/neo_django_country/info/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__neo_django_country__model.js' */ 'E:/web_work/corona_virus/src/pages/neo_django_country/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__neo_django_country__info__index" */ '../neo_django_country/info/index.js'),
            })
          : require('../neo_django_country/info/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/neo_django_country_search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__neo_django_country_search__model.js' */ 'E:/web_work/corona_virus/src/pages/neo_django_country_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__neo_django_country_search__index" */ '../neo_django_country_search/index.js'),
            })
          : require('../neo_django_country_search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/neo_django_country_search/info',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__neo_django_country_search__info__model.js' */ 'E:/web_work/corona_virus/src/pages/neo_django_country_search/info/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__neo_django_country_search__model.js' */ 'E:/web_work/corona_virus/src/pages/neo_django_country_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__neo_django_country_search__info__index" */ '../neo_django_country_search/info/index.js'),
            })
          : require('../neo_django_country_search/info/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/ol_image_search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__ol_image_search__model.js' */ 'E:/web_work/corona_virus/src/pages/ol_image_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__ol_image_search__index" */ '../ol_image_search/index.js'),
            })
          : require('../ol_image_search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/ol_image_search/search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__ol_image_search__model.js' */ 'E:/web_work/corona_virus/src/pages/ol_image_search/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__ol_image_search__search__index" */ '../ol_image_search/search/index.js'),
            })
          : require('../ol_image_search/search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/ol_mapproxy_tool',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__ol_mapproxy_tool__index" */ '../ol_mapproxy_tool/index.js'),
            })
          : require('../ol_mapproxy_tool/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/ol_mapproxy_tool/tools',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__ol_mapproxy_tool__tools__index" */ '../ol_mapproxy_tool/tools/index.js'),
            })
          : require('../ol_mapproxy_tool/tools/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/ol_mobile',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__ol_mobile__model.js' */ 'E:/web_work/corona_virus/src/pages/ol_mobile/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__ol_mobile__index" */ '../ol_mobile/index.js'),
            })
          : require('../ol_mobile/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/ol_mobile/source',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__ol_mobile__model.js' */ 'E:/web_work/corona_virus/src/pages/ol_mobile/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__ol_mobile__source__index" */ '../ol_mobile/source/index.js'),
            })
          : require('../ol_mobile/source/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers__index" */ '../openlayers/index.js'),
            })
          : require('../openlayers/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers/pie',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers__pie__index" */ '../openlayers/pie/index.js'),
            })
          : require('../openlayers/pie/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers/source',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers__source__index" */ '../openlayers/source/index.js'),
            })
          : require('../openlayers/source/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers2',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers2__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers2/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers2__index" */ '../openlayers2/index.js'),
            })
          : require('../openlayers2/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers3',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers3__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers3/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers3__index" */ '../openlayers3/index.js'),
            })
          : require('../openlayers3/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers_fangwu',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers_fangwu__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers_fangwu/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers_fangwu__index" */ '../openlayers_fangwu/index.js'),
            })
          : require('../openlayers_fangwu/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers_geodjango',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers_geodjango__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers_geodjango/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers_geodjango__index" */ '../openlayers_geodjango/index.js'),
            })
          : require('../openlayers_geodjango/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/openlayers_nongye',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__openlayers_nongye__model.js' */ 'E:/web_work/corona_virus/src/pages/openlayers_nongye/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__openlayers_nongye__index" */ '../openlayers_nongye/index.js'),
            })
          : require('../openlayers_nongye/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/other/client',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__other__client__index" */ '../other/client/index.js'),
            })
          : require('../other/client/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/other',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__other__index" */ '../other/index.js'),
            })
          : require('../other/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/PigDisease',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__PigDisease__model.js' */ 'E:/web_work/corona_virus/src/pages/PigDisease/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__PigDisease__index" */ '../PigDisease/index.js'),
            })
          : require('../PigDisease/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/PigDisease/search',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__PigDisease__model.js' */ 'E:/web_work/corona_virus/src/pages/PigDisease/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__PigDisease__search__index" */ '../PigDisease/search/index.js'),
            })
          : require('../PigDisease/search/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/relationshipdb',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__relationshipdb__index" */ '../relationshipdb/index.js'),
            })
          : require('../relationshipdb/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/relationshipdb/kuang',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__relationshipdb__kuang__model.js' */ 'E:/web_work/corona_virus/src/pages/relationshipdb/kuang/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__relationshipdb__kuang__index" */ '../relationshipdb/kuang/index.js'),
            })
          : require('../relationshipdb/kuang/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/relationshipdb/student',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__relationshipdb__student__model.js' */ 'E:/web_work/corona_virus/src/pages/relationshipdb/student/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__relationshipdb__student__index" */ '../relationshipdb/student/index.js'),
            })
          : require('../relationshipdb/student/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/spatialdb',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__spatialdb__model.js' */ 'E:/web_work/corona_virus/src/pages/spatialdb/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__spatialdb__index" */ '../spatialdb/index.js'),
            })
          : require('../spatialdb/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/student',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__student__model.js' */ 'E:/web_work/corona_virus/src/pages/student/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__student__index" */ '../student/index.js'),
            })
          : require('../student/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/supermap_ol',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__supermap_ol__model.js' */ 'E:/web_work/corona_virus/src/pages/supermap_ol/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__supermap_ol__index" */ '../supermap_ol/index.js'),
            })
          : require('../supermap_ol/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/system/visualization',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__system__visualization__model.js' */ 'E:/web_work/corona_virus/src/pages/system/visualization/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__system__visualization__index" */ '../system/visualization/index.js'),
            })
          : require('../system/visualization/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/system/visualization/pie/fun',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__system__visualization__model.js' */ 'E:/web_work/corona_virus/src/pages/system/visualization/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__system__visualization__pie__fun" */ '../system/visualization/pie/fun.js'),
            })
          : require('../system/visualization/pie/fun.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/system/visualization/pie',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__system__visualization__model.js' */ 'E:/web_work/corona_virus/src/pages/system/visualization/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__system__visualization__pie__index" */ '../system/visualization/pie/index.js'),
            })
          : require('../system/visualization/pie/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/system/visualization/source',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__system__visualization__model.js' */ 'E:/web_work/corona_virus/src/pages/system/visualization/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__system__visualization__source__index" */ '../system/visualization/source/index.js'),
            })
          : require('../system/visualization/source/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/user',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__user__model.js' */ 'E:/web_work/corona_virus/src/pages/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__user__index" */ '../user/index.js'),
            })
          : require('../user/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/user/login',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__user__model.js' */ 'E:/web_work/corona_virus/src/pages/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__user__login__index" */ '../user/login/index.js'),
            })
          : require('../user/login/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        path: '/user/register',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__user__model.js' */ 'E:/web_work/corona_virus/src/pages/user/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__user__register__index" */ '../user/register/index.js'),
            })
          : require('../user/register/index.js').default,
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
      {
        component: () =>
          React.createElement(
            require('E:/web_work/corona_virus/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: false },
          ),
        _title: 'supermap-study',
        _title_default: 'supermap-study',
      },
    ],
    _title: 'supermap-study',
    _title_default: 'supermap-study',
  },
  {
    component: () =>
      React.createElement(
        require('E:/web_work/corona_virus/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: false },
      ),
    _title: 'supermap-study',
    _title_default: 'supermap-study',
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return <Router history={history}>{renderRoutes(routes, props)}</Router>;
  }
}
