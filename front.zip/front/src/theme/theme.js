
module.exports = Object.assign(
    {
        '@primary-color': '#4570FF',
        '@text-color': '#333', // 主文本色
        '@slider-track-background-color': '@primary-color',
        '@bg-color': '#f5f5f5'
    }
);
  