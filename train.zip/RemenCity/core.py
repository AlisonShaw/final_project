import  csv
import  requests
from itertools import combinations
from common import  BaseInfo,writerHeardName
from operator import itemgetter
import time
from contextlib import suppress
from datetime import datetime,timedelta



# 读取目标火车站
stations = []
with open('./cityname.txt', encoding='utf-8',mode ="r") as f:
    lines = f.readlines()
    for i in lines:
        stations.append(i.replace("\n",""))


#火车站和火车站编号映射
station_name = {}
name_station = {}
with open('../data/station.txt', encoding='utf-8',mode ="r") as f:
    lines = f.readlines()
    for i in lines:
        temps = i.split(' ')
        station_name[temps[0]] = temps[1][:-1]
        name_station[temps[1][:-1]] = temps[0]


crawerPool = []
for a,b in combinations(stations,2):
    crawerPool.append([a,b])
    crawerPool.append([b,a])


heardName = BaseInfo.heardName
outfilePath = "./train.csv"
sunccessPath = "./success.csv"
writerHeardName(outfilePath,heardName)


successPair = []

try:
    with open(sunccessPath,"r",encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        for each in reader:
            successPair.append(each)
except Exception as e:
    print(e)

print(successPair)
for cityA,cityB in crawerPool:
    dateLength = 8
    for delta in range(2,dateLength):
        now = datetime.now()
        date = now + timedelta(days = delta)
        depDate = date.strftime('%Y-%m-%d')
        startDate = depDate
        if [cityA,cityB,startDate] not  in successPair:
            # startDate = "2021-02-16"
            fromName = station_name.get(cityA)
            toName = station_name.get(cityB)
            url = 'https://i.meituan.com/uts/train/train/querytripnew?fromPC=1' \
                  '&train_source=meituanpc@wap' \
                  '&from_station_telecode={}&to_station_telecode={}&yupiaoThreshold=0&start_date={}' \
                  '&isStudentBuying=false'.format(fromName,toName,startDate)

            headers = BaseInfo.headers
            # time.sleep(1)
            response = requests.get(url,headers = headers)
            jsonObj = response.json()

            for train in jsonObj['data']['trains']:
                keys = ["trainDate","train_no","full_train_code",'start_time',"arrive_time","run_time","from_station_name",
                        "from_station_telecode","to_station_name","to_station_telecode"]
                values = itemgetter(*keys)(train)
                for seats in train['seats']:
                    trainInfo = {"seat_type_name": seats['seat_type_name'],"seat_min_price": seats['seat_min_price'],
                                 "seat_yupiao": seats['seat_yupiao']}
                    for key,value in zip(keys,values):
                        trainInfo[key] = value
                    with open(outfilePath,encoding = "utf-8-sig",mode = "a",newline = "",errors = "ignore") as f:
                        wiriter = csv.DictWriter(f,fieldnames = heardName,extrasaction = "ignore")
                        wiriter.writerow(trainInfo)
                    print(trainInfo)
            with open(sunccessPath,"a",encoding = "utf-8-sig",newline = "") as f:
                writer = csv.writer(f)
                writer.writerow([cityA,cityB,startDate])

            print(f"{cityA}----->{cityB} is down !")
        else:
            print(f"{cityA}----->{cityB} is repeated !")
